"use strict";

/* class SpErrorHandler {
  constructor() {
    this.success = 0;
    this.ErrorMessage = "";
  }
  set success(success) {
    this._success = success;
  }

  get success() {
    return this._success;
  }

  set ErrorMessage(ErrorMessage) {
    this._ErrorMessage = ErrorMessage;
  }

  get ErrorMessage() {
    return this._ErrorMessage;
  }
}

module.exports = SpErrorHandler; */

module.exports.errorHandler = { success: 0, ErrorMessage: "" };
