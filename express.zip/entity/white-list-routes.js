"use strict";

exports.routes = ["/users", "/users/login"];
